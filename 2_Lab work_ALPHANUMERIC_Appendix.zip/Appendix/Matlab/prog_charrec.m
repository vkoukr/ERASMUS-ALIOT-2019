clear all;
tic;
%[alphabet,targets]=letno(0);
%letplot(alphabet(:,6));	
echo off
Out_Input=0;
while Out_Input==0;
   answer = inputdlg({'File name of input data', 'Sum-squared error goal:', 'Max. number of epoch to train Neural Network:', 'Struct. of Neural Network','Size of Characters[rows columns]','Range of noise','Tests number'},'Lab #5 Obraz Recognition:',1,{'input.csv','0.01','5000','64 10 10','8 8','1:10','5'});
   if isempty(answer)
      button = questdlg('Do you want to continue?','Continue Operation','Yes','No','Help','No');
      if strcmp(button,'Yes')   
         
      elseif strcmp(button,'No')
         Quit;
      end   
   else
      Out_Input=1;
   end
end
Input_File = answer{1};
train_accuracy = str2num(answer{2});
train_epoch = str2num(answer{3});
Stru_Neur = str2num(answer{4});
Char_size=str2num(answer{5});
noise_range = str2num(answer{6});
max_test=str2num(answer{7});

alphabet=dlmread(Input_File,';')';
targets=eye(size(alphabet,2));

%    NEWFF   - Inititializes feed-forward networks.
%    TRAINGDX - Trains a feed-forward network with faster backpropagation.
%    SIM   - Simulates feed-forward networks.


[R,Q] = size(alphabet);
[S2,Q] = size(targets);

%    DEFINING THE NETWORK

net = newff(minmax(alphabet),Stru_Neur(2:3),{'logsig' 'logsig'},'traingdx');
net.LW{2,1} = net.LW{2,1}*0.001;
net.b{2} = net.b{2}*0.01;

%pause % Strike any key to train the network...
%    TRAINING THE NETWORK WITHOUT NOISE
%    ==================================

net.performFcn = 'sse';        % Sum-Squared Error performance function
net.trainParam.goal = train_accuracy;     % Sum-squared error goal.
net.trainParam.show = 20;      % Frequency of progress displays (in epochs).
net.trainParam.epochs = train_epoch;  % Maximum number of epochs to train.
net.trainParam.mc = 0.95;      % Momentum constant.

P = alphabet;
T = targets;

[net,tr] = train(net,P,T);

% SET TESTING PARAMETERS
%========================
%noise_range = 1:1:10;
%max_test = 5;
network1 = [];
network2 = [];
T = targets;

% PERFORM THE TEST
for noiselevel = noise_range
  fprintf('Testing networks with noise level of %.2f.\n',noiselevel);
  errors1 = 0;
  errors2 = 0;

  for l=1:max_test
    P = noisy(alphabet,noiselevel);
    A = sim(net,P);
    AA = compet(A);
    errors1 = errors1 + sum(sum(abs(AA-T)));
    f=figure('name',sprintf('Noise level=%d   Test=%d',noiselevel,l),'color',[1 1 0.6]);
    for i=1:size(P,2) 
       subplot(size(P,2),3,i*3-3+1); 
       letplot(alphabet(:,i),Char_size(1),Char_size(2)); 
       subplot(size(P,2),3,i*3-3+2); 
       letplot(P(:,i),Char_size(1),Char_size(2)); 
       subplot(size(P,2),3,i*3-3+3); 
       [temp,r]=max(AA(:,i));
       letplot(alphabet(:,r),Char_size(1),Char_size(2));
       %bar(AA(:,i)); 
    end
    text(-120,-120,'Real value');
    text(-70,-120,'Noised inputs');
    text(-20,-120,'Classificaton Rezuls');
    drawnow;
  end
  % AVERAGE ERRORS FOR 100 SETS OF 26 TARGET VECTORS.
  network1 = [network1 100-(errors1/(max_test*size(alphabet,2)))*100];
end
echo on

%    DISPLAY RESULTS
figure;
plot(noise_range,network1,'-');
title('Percentage of Recognition');
xlabel('Noise Level');
ylabel('Percent of recognition');

%    Network 1, trained without noise, has more errors due
%    to noise than does Network 2, which was trained with noise.

echo off
disp('End of APPCR1')
z=toc
z=z/60

%figure;
%for i=1:10 subplot(2,10,i); plotchar(alphabet(:,i)); subplot(2,10,10+i); plotchar(P(:,i)); end
%[v,r]=max(sim(netn,P2(:,5)))

%for i=1:size(P,2) subplot(size(P,2),3,i*3-3+1); letplot(alphabet(:,i),Char_size(1),Char_size(2)); subplot(size(P,2),3,i*3-3+2); letplot(P(:,i),Char_size(1),Char_size(2)); subplot(size(P,2),3,i*3-3+3); bar(AA(:,i)); end

