%% ----- First part

clear all;

tempDir='CIFAR-100_part\'

imds = imageDatastore(fullfile(tempDir,''),...
'IncludeSubfolders',true,'FileExtensions','.png','LabelSource','foldernames')

properties(imds);

fname_imds=imds.Files;

labels_imds=imds.Labels;

methods(imds);

countEachLabel(imds)

image(readimage(imds,6))
im_6=readimage(imds,6)

%%  --- Second part
size_im6=size(im_6)

net = alexnet;
input_sz = net.Layers(1).InputSize;


im_6_new=imresize (im_6(:,:,1), [227 227] );
im_6_net(:,:,1)=im_6_new;
im_6_net(:,:,2)=im_6_new;
im_6_net(:,:,3)=im_6_new;
figure; subplot(1,2,1); imshow(im_6(:,:,1),[]);
subplot(1,2,2); imshow(im_6_net,[]); 

prediction=classify(net,im_6_net);
disp(prediction)

num_labels=imds.countEachLabel;
[train_imds,test_imds]=splitEachLabel(imds,num_labels{1,2}-1,'randomized');

augmented_imds = augmentedImageDatastore([227 227 3],test_imds);


prediction=classify(net,augmented_imds);

numel=length(test_imds.Labels); %--- Number of categories
for i=1:numel
    subplot(1,numel,i);
    imshow(readimage(test_imds,i));
    title(sprintf('%s',prediction(i)));
end